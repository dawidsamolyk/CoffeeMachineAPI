package edu.issi.machine.id;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>ObjectWithIdentityTest</code> contains tests for the class
 * <code>{@link ObjectWithIdentity}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ObjectWithIdentityTest {
    /**
     * An instance of the class being tested.
     *
     * @see ObjectWithIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private ObjectWithIdentity fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see ObjectWithIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public ObjectWithIdentity getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new ObjectWithIdentity((Identity) null);
	}
	return fixture;
    }

    /**
     * Run the ObjectWithIdentity(Identity) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testObjectWithIdentity_1() throws Exception {
	final Identity id = null;

	final ObjectWithIdentity result = new ObjectWithIdentity(id);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture_1() throws Exception {
	final ObjectWithIdentity fixture2 = getFixture();
	final Object obj = "1";

	final boolean result = fixture2.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture_2() throws Exception {
	final ObjectWithIdentity fixture2 = getFixture();
	final Object obj = null;

	final boolean result = fixture2.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture_3() throws Exception {
	final ObjectWithIdentity fixture2 = getFixture();
	final Object obj = new ObjectWithIdentity((Identity) null);

	final boolean result = fixture2.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture_1() throws Exception {
	final ObjectWithIdentity fixture2 = getFixture();

	final int result = fixture2.hashCode();

	// add additional test code here
	assertEquals(31, result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ObjectWithIdentityTest.class);
    }
}