package edu.issi.machine.id;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.issi.machine.product.ingredient.Unit;

/**
 * The class <code>PropertyIdentityTest</code> contains tests for the class
 * <code>{@link PropertyIdentity}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class PropertyIdentityTest {
    /**
     * An instance of the class being tested.
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private PropertyIdentity fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private PropertyIdentity fixture2;

    /**
     * An instance of the class being tested.
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private PropertyIdentity fixture3;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public PropertyIdentity getFixture1() throws Exception {
	if (fixture1 == null) {
	    fixture1 = new PropertyIdentity(0, "", Unit.BAR);
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public PropertyIdentity getFixture2() throws Exception {
	if (fixture2 == null) {
	    fixture2 = new PropertyIdentity(1, "0123456789", Unit.C);
	}
	return fixture2;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see PropertyIdentity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public PropertyIdentity getFixture3() throws Exception {
	if (fixture3 == null) {
	    fixture3 = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	}
	return fixture3;
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_1() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.BAR;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_2() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.C;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_3() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.G;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_4() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.KG;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_5() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.L;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_6() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.ML;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_7() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.BAR;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_8() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.C;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_9() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.G;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_10() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.KG;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_11() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.L;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_12() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.ML;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_13() throws Exception {
	final int id = 1;
	final String name = "";
	final Unit unit = Unit.BAR;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_14() throws Exception {
	final int id = 7;
	final String name = "0123456789";
	final Unit unit = Unit.C;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_15() throws Exception {
	final int id = 1;
	final String name = "";
	final Unit unit = Unit.G;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_16() throws Exception {
	final int id = 7;
	final String name = "0123456789";
	final Unit unit = Unit.KG;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_17() throws Exception {
	final int id = 1;
	final String name = "";
	final Unit unit = Unit.L;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_18() throws Exception {
	final int id = 7;
	final String name = "0123456789";
	final Unit unit = Unit.ML;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_19() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.BAR;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_20() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.C;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_21() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.G;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_22() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.KG;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_23() throws Exception {
	final int id = 1;
	final String name = "0123456789";
	final Unit unit = Unit.L;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_24() throws Exception {
	final int id = 0;
	final String name = "";
	final Unit unit = Unit.ML;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_25() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.BAR;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_26() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.C;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_27() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.G;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_28() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.KG;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_29() throws Exception {
	final int id = 7;
	final String name = "";
	final Unit unit = Unit.L;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=]", result.toString());
    }

    /**
     * Run the PropertyIdentity(int,String,Unit) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPropertyIdentity_30() throws Exception {
	final int id = 0;
	final String name = "0123456789";
	final Unit unit = Unit.ML;

	final PropertyIdentity result = new PropertyIdentity(id, name, unit);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the Unit getUnit() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetUnit_fixture1_1() throws Exception {
	final PropertyIdentity fixture = getFixture1();

	final Unit result = fixture.getUnit();

	// add additional test code here
	assertNotNull(result);
	assertEquals("bar", result.toString());
	assertEquals("BAR", result.name());
	assertEquals(4, result.ordinal());
    }

    /**
     * Run the Unit getUnit() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetUnit_fixture2_1() throws Exception {
	final PropertyIdentity fixture = getFixture2();

	final Unit result = fixture.getUnit();

	// add additional test code here
	assertNotNull(result);
	assertEquals("*C", result.toString());
	assertEquals("C", result.name());
	assertEquals(5, result.ordinal());
    }

    /**
     * Run the Unit getUnit() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetUnit_fixture3_1() throws Exception {
	final PropertyIdentity fixture = getFixture3();

	final Unit result = fixture.getUnit();

	// add additional test code here
	assertNotNull(result);
	assertEquals("g", result.toString());
	assertEquals("G", result.name());
	assertEquals(0, result.ordinal());
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(PropertyIdentityTest.class);
    }
}