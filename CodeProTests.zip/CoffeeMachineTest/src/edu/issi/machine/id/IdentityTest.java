package edu.issi.machine.id;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>IdentityTest</code> contains tests for the class
 * <code>{@link Identity}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class IdentityTest {
    /**
     * An instance of the class being tested.
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Identity fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Identity fixture2;

    /**
     * An instance of the class being tested.
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Identity fixture3;

    /**
     * An instance of the class being tested.
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Identity fixture4;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Identity getFixture1() throws Exception {
	if (fixture1 == null) {
	    fixture1 = new Identity(0);
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Identity getFixture2() throws Exception {
	if (fixture2 == null) {
	    fixture2 = new Identity(0);
	    fixture2.changeName("1");
	}
	return fixture2;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Identity getFixture3() throws Exception {
	if (fixture3 == null) {
	    fixture3 = new Identity(0, "");
	}
	return fixture3;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Identity
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Identity getFixture4() throws Exception {
	if (fixture4 == null) {
	    fixture4 = new Identity(1, "0123456789");
	}
	return fixture4;
    }

    /**
     * Run the Identity(int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_1() throws Exception {
	final int id = 0;

	final Identity result = new Identity(id);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0]", result.toString());
    }

    /**
     * Run the Identity(int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_2() throws Exception {
	final int id = 1;

	final Identity result = new Identity(id);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=1]", result.toString());
    }

    /**
     * Run the Identity(int,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_3() throws Exception {
	final int id = 0;
	final String name = "";

	final Identity result = new Identity(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=]", result.toString());
    }

    /**
     * Run the Identity(int,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_4() throws Exception {
	final int id = 1;
	final String name = "0123456789";

	final Identity result = new Identity(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=0123456789]", result.toString());
    }

    /**
     * Run the Identity(int,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_5() throws Exception {
	final int id = 1;
	final String name = "";

	final Identity result = new Identity(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=]", result.toString());
    }

    /**
     * Run the Identity(int,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIdentity_6() throws Exception {
	final int id = 0;
	final String name = "0123456789";

	final Identity result = new Identity(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0123456789]", result.toString());
    }

    /**
     * Run the String changeName(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testChangeName_fixture1_1() throws Exception {
	final Identity fixture = getFixture1();
	final String newName = null;

	final String result = fixture.changeName(newName);

	// add additional test code here
	assertEquals("0", result);
    }

    /**
     * Run the String changeName(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testChangeName_fixture2_1() throws Exception {
	final Identity fixture = getFixture2();
	final String newName = null;

	final String result = fixture.changeName(newName);

	// add additional test code here
	assertEquals("1", result);
    }

    /**
     * Run the String changeName(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testChangeName_fixture3_1() throws Exception {
	final Identity fixture = getFixture3();
	final String newName = null;

	final String result = fixture.changeName(newName);

	// add additional test code here
	assertEquals("", result);
    }

    /**
     * Run the String changeName(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testChangeName_fixture4_1() throws Exception {
	final Identity fixture = getFixture4();
	final String newName = null;

	final String result = fixture.changeName(newName);

	// add additional test code here
	assertEquals("0123456789", result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_1() throws Exception {
	final Identity fixture = getFixture1();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_1() throws Exception {
	final Identity fixture = getFixture2();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_1() throws Exception {
	final Identity fixture = getFixture3();
	final Object obj = new Identity(0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_1() throws Exception {
	final Identity fixture = getFixture4();
	final Identity obj = new Identity(0);
	obj.changeName("1");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_2() throws Exception {
	final Identity fixture = getFixture1();
	final Object obj = new Identity(0, "");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_2() throws Exception {
	final Identity fixture = getFixture2();
	final Object obj = new Identity(1, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_2() throws Exception {
	final Identity fixture = getFixture4();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_3() throws Exception {
	final Identity fixture = getFixture1();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_3() throws Exception {
	final Identity fixture = getFixture2();
	final Object obj = new Identity(0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_2() throws Exception {
	final Identity fixture = getFixture3();
	final Identity obj = new Identity(0);
	obj.changeName("1");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_3() throws Exception {
	final Identity fixture = getFixture4();
	final Object obj = new Identity(0, "");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_4() throws Exception {
	final Identity fixture = getFixture1();
	final Object obj = new Identity(1, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_3() throws Exception {
	final Identity fixture = getFixture3();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_4() throws Exception {
	final Identity fixture = getFixture4();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_5() throws Exception {
	final Identity fixture = getFixture1();
	final Object obj = new Identity(0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_4() throws Exception {
	final Identity fixture = getFixture2();
	final Identity obj = new Identity(0);
	obj.changeName("1");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_4() throws Exception {
	final Identity fixture = getFixture3();
	final Object obj = new Identity(0, "");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_5() throws Exception {
	final Identity fixture = getFixture4();
	final Object obj = new Identity(1, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_5() throws Exception {
	final Identity fixture = getFixture2();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_5() throws Exception {
	final Identity fixture = getFixture3();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture4_6() throws Exception {
	final Identity fixture = getFixture4();
	final Object obj = new Identity(0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_6() throws Exception {
	final Identity fixture = getFixture1();
	final Identity obj = new Identity(0);
	obj.changeName("1");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_6() throws Exception {
	final Identity fixture = getFixture2();
	final Object obj = new Identity(0, "");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_6() throws Exception {
	final Identity fixture = getFixture3();
	final Object obj = new Identity(1, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture1_1() throws Exception {
	final Identity fixture = getFixture1();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(1009, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture2_1() throws Exception {
	final Identity fixture = getFixture2();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(1010, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture3_1() throws Exception {
	final Identity fixture = getFixture3();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(961, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture4_1() throws Exception {
	final Identity fixture = getFixture4();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(1584876005, result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture1_1() throws Exception {
	final Identity fixture = getFixture1();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("Identity [id=0, name=0]", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture2_1() throws Exception {
	final Identity fixture = getFixture2();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("Identity [id=0, name=1]", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture3_1() throws Exception {
	final Identity fixture = getFixture3();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("Identity [id=0, name=]", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture4_1() throws Exception {
	final Identity fixture = getFixture4();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("Identity [id=1, name=0123456789]", result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(IdentityTest.class);
    }
}