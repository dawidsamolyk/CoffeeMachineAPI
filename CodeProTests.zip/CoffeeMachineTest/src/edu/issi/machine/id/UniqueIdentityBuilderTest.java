package edu.issi.machine.id;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>UniqueIdentityBuilderTest</code> contains tests for the class
 * <code>{@link UniqueIdentityBuilder}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class UniqueIdentityBuilderTest {
    /**
     * An instance of the class being tested.
     *
     * @see UniqueIdentityBuilder
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private UniqueIdentityBuilder fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see UniqueIdentityBuilder
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public UniqueIdentityBuilder getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new UniqueIdentityBuilder();
	}
	return fixture;
    }

    /**
     * Run the UniqueIdentityBuilder() constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testUniqueIdentityBuilder_1() throws Exception {

	final UniqueIdentityBuilder result = new UniqueIdentityBuilder();

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_1() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 0;
	final String name = "";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0]", result.toString());
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_2() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 1;
	final String name = "0123456789";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=1]", result.toString());
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_3() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 7;
	final String name = "0123456789";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=7]", result.toString());
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_4() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 1;
	final String name = "";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=1, name=1]", result.toString());
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_5() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 7;
	final String name = "";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=7, name=7]", result.toString());
    }

    /**
     * Run the Identity build(int,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testBuild_fixture_6() throws Exception {
	final UniqueIdentityBuilder fixture2 = getFixture();
	final int id = 0;
	final String name = "0123456789";

	final Identity result = fixture2.build(id, name);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Identity [id=0, name=0]", result.toString());
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(UniqueIdentityBuilderTest.class);
    }
}