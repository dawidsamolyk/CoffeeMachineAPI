package edu.issi.machine.operation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>OperationStateTest</code> contains tests for the class
 * <code>{@link OperationState}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class OperationStateTest {
    /**
     * An instance of the class being tested.
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private OperationState fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private OperationState fixture2;

    /**
     * An instance of the class being tested.
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private OperationState fixture3;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public OperationState getFixture1() throws Exception {
	if (fixture1 == null) {
	    fixture1 = new OperationState(Status.ERROR, 0);
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public OperationState getFixture2() throws Exception {
	if (fixture2 == null) {
	    fixture2 = new OperationState(Status.OK, "0123456789");
	}
	return fixture2;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see OperationState
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public OperationState getFixture3() throws Exception {
	if (fixture3 == null) {
	    fixture3 = new OperationState(Status.OK, 1);
	}
	return fixture3;
    }

    /**
     * Run the OperationState(Status) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_1() throws Exception {
	final Status status = Status.OK;

	final OperationState result = new OperationState(status);

	// add additional test code here
	assertNotNull(result);
	assertEquals(null, result.getDescription());
	assertEquals("[OK] ", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalStateException.class)
    public void testOperationState_2() throws Exception {
	final Status status = Status.ERROR;

	final OperationState result = new OperationState(status);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the OperationState(Status) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalStateException.class)
    public void testOperationState_3() throws Exception {
	final Status status = Status.WARNING;

	final OperationState result = new OperationState(status);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_4() throws Exception {
	final Status status = Status.ERROR;
	final int stateCodeNumber = 0;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 0", result.getDescription());
	assertEquals("[ERROR] Blad numer: 0", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_5() throws Exception {
	final Status status = Status.OK;
	final int stateCodeNumber = 1;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals(null, result.getDescription());
	assertEquals("[OK] ", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_6() throws Exception {
	final Status status = Status.WARNING;
	final int stateCodeNumber = 7;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 7", result.getDescription());
	assertEquals("[WARNING] Blad numer: 7", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_7() throws Exception {
	final Status status = Status.OK;
	final int stateCodeNumber = 0;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals(null, result.getDescription());
	assertEquals("[OK] ", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_8() throws Exception {
	final Status status = Status.WARNING;
	final int stateCodeNumber = 1;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 1", result.getDescription());
	assertEquals("[WARNING] Blad numer: 1", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_9() throws Exception {
	final Status status = Status.ERROR;
	final int stateCodeNumber = 7;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 7", result.getDescription());
	assertEquals("[ERROR] Blad numer: 7", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_10() throws Exception {
	final Status status = Status.WARNING;
	final int stateCodeNumber = 0;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 0", result.getDescription());
	assertEquals("[WARNING] Blad numer: 0", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_11() throws Exception {
	final Status status = Status.ERROR;
	final int stateCodeNumber = 1;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Blad numer: 1", result.getDescription());
	assertEquals("[ERROR] Blad numer: 1", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,int) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_12() throws Exception {
	final Status status = Status.OK;
	final int stateCodeNumber = 7;

	final OperationState result = new OperationState(status, stateCodeNumber);

	// add additional test code here
	assertNotNull(result);
	assertEquals(null, result.getDescription());
	assertEquals("[OK] ", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_13() throws Exception {
	final Status status = Status.OK;
	final String description = "0123456789";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
	assertEquals("0123456789", result.getDescription());
	assertEquals("[OK] 0123456789", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_14() throws Exception {
	final Status status = Status.WARNING;
	final String description = "0123456789";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
	assertEquals("0123456789", result.getDescription());
	assertEquals("[WARNING] 0123456789", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_15() throws Exception {
	final Status status = Status.OK;
	final String description = "";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
	assertEquals("", result.getDescription());
	assertEquals("[OK] ", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testOperationState_16() throws Exception {
	final Status status = Status.ERROR;
	final String description = "0123456789";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
	assertEquals("0123456789", result.getDescription());
	assertEquals("[ERROR] 0123456789", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalStateException.class)
    public void testOperationState_17() throws Exception {
	final Status status = Status.ERROR;
	final String description = "";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the OperationState(Status,String) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalStateException.class)
    public void testOperationState_18() throws Exception {
	final Status status = Status.WARNING;
	final String description = "";

	final OperationState result = new OperationState(status, description);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_1() throws Exception {
	final OperationState fixture = getFixture1();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_1() throws Exception {
	final OperationState fixture = getFixture2();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_1() throws Exception {
	final OperationState fixture = getFixture3();
	final Object obj = new OperationState(Status.ERROR, 0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_2() throws Exception {
	final OperationState fixture = getFixture1();
	final Object obj = new OperationState(Status.OK, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_2() throws Exception {
	final OperationState fixture = getFixture2();
	final Object obj = new OperationState(Status.OK, 1);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_3() throws Exception {
	final OperationState fixture = getFixture1();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_3() throws Exception {
	final OperationState fixture = getFixture2();
	final Object obj = new OperationState(Status.ERROR, 0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_2() throws Exception {
	final OperationState fixture = getFixture3();
	final Object obj = new OperationState(Status.OK, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_4() throws Exception {
	final OperationState fixture = getFixture1();
	final Object obj = new OperationState(Status.OK, 1);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_3() throws Exception {
	final OperationState fixture = getFixture3();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_5() throws Exception {
	final OperationState fixture = getFixture1();
	final Object obj = new OperationState(Status.ERROR, 0);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_4() throws Exception {
	final OperationState fixture = getFixture2();
	final Object obj = new OperationState(Status.OK, "0123456789");

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_4() throws Exception {
	final OperationState fixture = getFixture3();
	final Object obj = new OperationState(Status.OK, 1);

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_5() throws Exception {
	final OperationState fixture = getFixture2();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture3_5() throws Exception {
	final OperationState fixture = getFixture3();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the String getCompensatedStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetCompensatedStatus_fixture1_1() throws Exception {
	final OperationState fixture = getFixture1();

	final String result = fixture.getCompensatedStatus();

	// add additional test code here
	assertEquals("[ERROR] Blad numer: 0", result);
    }

    /**
     * Run the String getCompensatedStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetCompensatedStatus_fixture2_1() throws Exception {
	final OperationState fixture = getFixture2();

	final String result = fixture.getCompensatedStatus();

	// add additional test code here
	assertEquals("[OK] 0123456789", result);
    }

    /**
     * Run the String getCompensatedStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetCompensatedStatus_fixture3_1() throws Exception {
	final OperationState fixture = getFixture3();

	final String result = fixture.getCompensatedStatus();

	// add additional test code here
	assertEquals("[OK] ", result);
    }

    /**
     * Run the String getDescription() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetDescription_fixture1_1() throws Exception {
	final OperationState fixture = getFixture1();

	final String result = fixture.getDescription();

	// add additional test code here
	assertEquals("Blad numer: 0", result);
    }

    /**
     * Run the String getDescription() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetDescription_fixture2_1() throws Exception {
	final OperationState fixture = getFixture2();

	final String result = fixture.getDescription();

	// add additional test code here
	assertEquals("0123456789", result);
    }

    /**
     * Run the String getDescription() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetDescription_fixture3_1() throws Exception {
	final OperationState fixture = getFixture3();

	final String result = fixture.getDescription();

	// add additional test code here
	assertEquals(null, result);
    }

    /**
     * Run the Status getStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetStatus_fixture1_1() throws Exception {
	final OperationState fixture = getFixture1();

	final Status result = fixture.getStatus();

	// add additional test code here
	assertNotNull(result);
	assertEquals(true, result.requiresAttention());
	assertEquals("ERROR", result.name());
	assertEquals("ERROR", result.toString());
	assertEquals(2, result.ordinal());
    }

    /**
     * Run the Status getStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetStatus_fixture2_1() throws Exception {
	final OperationState fixture = getFixture2();

	final Status result = fixture.getStatus();

	// add additional test code here
	assertNotNull(result);
	assertEquals(false, result.requiresAttention());
	assertEquals("OK", result.name());
	assertEquals("OK", result.toString());
	assertEquals(0, result.ordinal());
    }

    /**
     * Run the Status getStatus() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGetStatus_fixture3_1() throws Exception {
	final OperationState fixture = getFixture3();

	final Status result = fixture.getStatus();

	// add additional test code here
	assertNotNull(result);
	assertEquals(false, result.requiresAttention());
	assertEquals("OK", result.name());
	assertEquals("OK", result.toString());
	assertEquals(0, result.ordinal());
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(OperationStateTest.class);
    }
}