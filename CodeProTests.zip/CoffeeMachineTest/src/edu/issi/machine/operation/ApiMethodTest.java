package edu.issi.machine.operation;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Method;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.issi.machine.api.Api;

/**
 * The class <code>ApiMethodTest</code> contains tests for the class
 * <code>{@link ApiMethod}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ApiMethodTest {
    /**
     * Run the ApiMethod(Api,Method) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testApiMethod_1() throws Exception {
	final Api api = new Api();
	final Method method = Api.class.getMethods()[0];

	final ApiMethod result = new ApiMethod(api, method);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:26)
	assertNotNull(result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ApiMethodTest.class);
    }
}