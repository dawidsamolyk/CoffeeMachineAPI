package edu.issi.machine.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.issi.machine.api.Api;
import edu.issi.machine.configuration.ConfigurationFile;
import edu.issi.machine.configuration.MachineConfigurationReader;

/**
 * The class <code>MachineControllerTest</code> contains tests for the class
 * <code>{@link MachineController}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class MachineControllerTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();
    
    /**
     * An instance of the class being tested.
     *
     * @see MachineController
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private MachineController fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see MachineController
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public MachineController getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new MachineController(new Api());
	}
	return fixture;
    }

    /**
     * Run the MachineController(Api) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testMachineController_1() throws Exception {
	final Api api = new Api();

	final MachineController result = new MachineController(api);

	// add additional test code here
	assertNotNull(result);
	assertEquals(false, result.isInterrupted());
	assertEquals(false, result.isAlive());
    }

    /**
     * Run the void restart() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRestart_fixture_1() throws Exception {
	final MachineController fixture2 = getFixture();

	exception.expect(UnsupportedOperationException.class);
	fixture2.restart();

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.UnsupportedOperationException: Nie mo�na uruchomi� maszyny
	// bez ustawionej konfiguracji!
	// at
	// edu.issi.machine.controller.MachineController.run(MachineController.java:47)
	// at
	// edu.issi.machine.controller.MachineController.restart(MachineController.java:68)
    }

    /**
     * Run the void run() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRun_fixture_1() throws Exception {
	final MachineController fixture2 = getFixture();

	exception.expect(UnsupportedOperationException.class);
	fixture2.run();

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.UnsupportedOperationException: Nie mo�na uruchomi� maszyny
	// bez ustawionej konfiguracji!
	// at
	// edu.issi.machine.controller.MachineController.run(MachineController.java:47)
    }

    /**
     * Run the void stopWorking() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testStopWorking_fixture_1() throws Exception {
	final MachineController fixture2 = getFixture();

	fixture2.stopWorking();

	// add additional test code here
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(MachineControllerTest.class);
    }
}