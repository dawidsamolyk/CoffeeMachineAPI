package edu.issi.machine;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * The class <code>ValidatorTest</code> contains tests for the class
 * <code>{@link Validator}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ValidatorTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_1() throws Exception {
	final Object[] table = new Object[] { null };
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_2() throws Exception {
	final Object[] table = new Object[] {};
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_3() throws Exception {
	final Object[] table = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_4() throws Exception {
	final Object[] table = new Object[] {};
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_5() throws Exception {
	final Object[] table = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenArrayContainsNullOrEmpty(Object[],String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenArrayContainsNullOrEmpty_6() throws Exception {
	final Object[] table = new Object[] { null };
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenArrayContainsNullOrEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenArrayContainsNullOrEmpty(Validator.java:62)
    }

    /**
     * Run the void throwExceptionWhenEmpty(List<?>,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_1() throws Exception {
	final List<Object> list = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(list, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:74)
    }

    /**
     * Run the void throwExceptionWhenEmpty(List<?>,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_2() throws Exception {
	final List<Object> list = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(list, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:74)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_3() throws Exception {
	final Object[] table = new Object[] { null };
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_4() throws Exception {
	final Object[] table = new Object[] {};
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_5() throws Exception {
	final Object[] table = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_6() throws Exception {
	final Object[] table = new Object[] {};
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_7() throws Exception {
	final Object[] table = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenEmpty(Object[],String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenEmpty_8() throws Exception {
	final Object[] table = new Object[] { null };
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenEmpty(table, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenEmpty(Validator.java:86)
    }

    /**
     * Run the void throwExceptionWhenListContainsNullOrEmpty(List<?>,String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenListContainsNullOrEmpty_1() throws Exception {
	final List<Object> list = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenListContainsNullOrEmpty(list, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenListContainsNullOrEmpty(Validator.java:98)
    }

    /**
     * Run the void throwExceptionWhenListContainsNullOrEmpty(List<?>,String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenListContainsNullOrEmpty_2() throws Exception {
	final List<Object> list = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenListContainsNullOrEmpty(list, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenListContainsNullOrEmpty(Validator.java:98)
    }

    /**
     * Run the void throwExceptionWhenMapContainsNullOrEmpty(Map<?,?>,String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenMapContainsNullOrEmpty_1() throws Exception {
	final Map<Object, Object> map = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenMapContainsNullOrEmpty(map, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenMapContainsNullOrEmpty(Validator.java:110)
    }

    /**
     * Run the void throwExceptionWhenMapContainsNullOrEmpty(Map<?,?>,String)
     * method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenMapContainsNullOrEmpty_2() throws Exception {
	final Map<Object, Object> map = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenMapContainsNullOrEmpty(map, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenMapContainsNullOrEmpty(Validator.java:110)
    }

    /**
     * Run the void throwExceptionWhenObjectIsNotCreated(Object,String) method
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenObjectIsNotCreated_1() throws Exception {
	final Object object = "1";
	final String exceptionMessage = "";

	Validator.throwExceptionWhenObjectIsNotCreated(object, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenObjectIsNotCreated(Object,String) method
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenObjectIsNotCreated_2() throws Exception {
	final Object object = "1";
	final String exceptionMessage = "0123456789";

	Validator.throwExceptionWhenObjectIsNotCreated(object, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenObjectIsNotCreated(Object,String) method
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenObjectIsNotCreated_3() throws Exception {
	final Object object = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenObjectIsNotCreated(object, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenObjectIsNotCreated(Object,String) method
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenObjectIsNotCreated_4() throws Exception {
	final Object object = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenObjectIsNotCreated(object, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_1() throws Exception {
	final String text = "";
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenTextIsEmpty(Validator.java:50)
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_2() throws Exception {
	final String text = "0";
	final String exceptionMessage = "0123456789";

	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_3() throws Exception {
	final String text = "1";
	final String exceptionMessage = "0123456789";

	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_4() throws Exception {
	final String text = null;
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenTextIsEmpty(Validator.java:50)
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_5() throws Exception {
	final String text = "0";
	final String exceptionMessage = "";

	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_6() throws Exception {
	final String text = "1";
	final String exceptionMessage = "";

	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_7() throws Exception {
	final String text = null;
	final String exceptionMessage = "";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException:
	// at
	// edu.issi.machine.Validator.throwExceptionWhenTextIsEmpty(Validator.java:50)
    }

    /**
     * Run the void throwExceptionWhenTextIsEmpty(String,String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testThrowExceptionWhenTextIsEmpty_8() throws Exception {
	final String text = "";
	final String exceptionMessage = "0123456789";

	exception.expect(IllegalArgumentException.class);
	Validator.throwExceptionWhenTextIsEmpty(text, exceptionMessage);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: 0123456789
	// at
	// edu.issi.machine.Validator.throwExceptionWhenTextIsEmpty(Validator.java:50)
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ValidatorTest.class);
    }
}