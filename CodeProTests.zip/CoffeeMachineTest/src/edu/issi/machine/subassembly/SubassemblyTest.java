package edu.issi.machine.subassembly;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Method;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.issi.machine.api.Api;
import edu.issi.machine.id.Identity;
import edu.issi.machine.operation.ApiMethod;
import edu.issi.machine.operation.Operation;

/**
 * The class <code>SubassemblyTest</code> contains tests for the class
 * <code>{@link Subassembly}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class SubassemblyTest {
    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_1() throws Exception {
	final Identity id = new Identity(0);
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });
	final Operation operation2 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });
	final Operation operation3 = null;

	final Subassembly result = new Subassembly(id, operation1, operation2, operation3);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_2() throws Exception {
	final Identity id = new Identity(0, "");
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_3() throws Exception {
	final Identity id = new Identity(1, "0123456789");
	final Operation operation1 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_4() throws Exception {
	final Identity id = new Identity(0, "");
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });
	final Operation operation2 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });
	final Operation operation3 = null;

	final Subassembly result = new Subassembly(id, operation1, operation2, operation3);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_5() throws Exception {
	final Identity id = new Identity(1, "0123456789");
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_6() throws Exception {
	final Identity id = new Identity(0);
	final Operation operation1 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_7() throws Exception {
	final Identity id = new Identity(1, "0123456789");
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });
	final Operation operation2 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });
	final Operation operation3 = null;

	final Subassembly result = new Subassembly(id, operation1, operation2, operation3);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_8() throws Exception {
	final Identity id = new Identity(0);
	final Operation operation1 = new Operation(new Identity(0), new ApiMethod[] {
	    new ApiMethod(new Api(), Object.class.getMethods()[0]),
	    new ApiMethod((Api) null, (Method) null), null });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Subassembly(Identity,Operation[]) constructor test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.lang.IllegalArgumentException.class)
    public void testSubassembly_9() throws Exception {
	final Identity id = new Identity(0, "");
	final Operation operation1 = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Object.class.getMethods()[0]) });

	final Subassembly result = new Subassembly(id, operation1);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(SubassemblyTest.class);
    }
}