package edu.issi.machine.subassembly.handler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Method;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.issi.machine.api.Api;
import edu.issi.machine.id.Identity;
import edu.issi.machine.operation.ApiMethod;
import edu.issi.machine.operation.Operation;
import edu.issi.machine.operation.OperationState;

/**
 * The class <code>HandlerTest</code> contains tests for the class
 * <code>{@link Handler}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class HandlerTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();

    /**
     * An instance of the class being tested.
     *
     * @see Handler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Handler fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see Handler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Handler fixture2;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Handler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Handler getFixture1() throws Exception {
	if (fixture1 == null) {
	    fixture1 = new DefaultHandler();
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Handler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Handler getFixture2() throws Exception {
	if (fixture2 == null) {
	    fixture2 = new DefaultHandler();
	    fixture2.next(new DefaultHandler());
	}
	return fixture2;
    }

    /**
     * Run the OperationState doOperation(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testDoOperation_fixture1_1() throws Exception {
	final Handler fixture = getFixture1();
	final Operation operation = null;

	final OperationState result = fixture.doOperation(operation);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Nie mo�na wykona� pustej operacji!", result.getDescription());
	assertEquals("[ERROR] Nie mo�na wykona� pustej operacji!", result.getCompensatedStatus());
    }

    /**
     * Run the OperationState doOperation(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testDoOperation_fixture2_1() throws Exception {
	final Handler fixture = getFixture2();
	final Operation operation = null;

	final OperationState result = fixture.doOperation(operation);

	// add additional test code here
	assertNotNull(result);
	assertEquals("Nie mo�na wykona� pustej operacji!", result.getDescription());
	assertEquals("[ERROR] Nie mo�na wykona� pustej operacji!", result.getCompensatedStatus());
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_1() throws Exception {
	final Handler fixture = getFixture1();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_1() throws Exception {
	final Handler fixture = getFixture2();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_2() throws Exception {
	final Handler fixture = getFixture1();
	final Object obj = new DefaultHandler();

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_2() throws Exception {
	final Handler fixture = getFixture2();
	final Handler obj = new DefaultHandler();
	obj.next(new DefaultHandler());

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_3() throws Exception {
	final Handler fixture = getFixture2();
	final Object obj = "1";

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_3() throws Exception {
	final Handler fixture = getFixture1();
	final Object obj = null;

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture2_4() throws Exception {
	final Handler fixture = getFixture2();
	final Object obj = new DefaultHandler();

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the boolean equals(Object) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testEquals_fixture1_4() throws Exception {
	final Handler fixture = getFixture1();
	final Handler obj = new DefaultHandler();
	obj.next(new DefaultHandler());

	final boolean result = fixture.equals(obj);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the OperationState executeNext(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testExecuteNext_fixture1_1() throws Exception {
	final Handler fixture = getFixture1();

	exception.expect(IllegalArgumentException.class);
	final Operation operation = new Operation(new Identity(0), new ApiMethod[] {
		new ApiMethod(new Api(), Api.class.getMethods()[0]),
		new ApiMethod((Api) null, (Method) null), null });

	final OperationState result = fixture.executeNext(operation);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:26)
	assertNotNull(result);
    }

    /**
     * Run the OperationState executeNext(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testExecuteNext_fixture2_1() throws Exception {
	final Handler fixture = getFixture2();

	final Operation operation = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Api.class.getMethods()[0]) });

	final OperationState result = fixture.executeNext(operation);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:26)
	assertNotNull(result);
    }

    /**
     * Run the OperationState executeNext(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testExecuteNext_fixture2_2() throws Exception {
	final Handler fixture = getFixture2();

	exception.expect(IllegalArgumentException.class);
	final Operation operation = new Operation(new Identity(0), new ApiMethod[] {
		new ApiMethod(new Api(), Api.class.getMethods()[0]),
		new ApiMethod((Api) null, (Method) null), null });

	final OperationState result = fixture.executeNext(operation);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:26)
	assertNotNull(result);
    }

    /**
     * Run the OperationState executeNext(Operation) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testExecuteNext_fixture1_2() throws Exception {
	final Handler fixture = getFixture1();
	final Operation operation = new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(
		new Api(), Api.class.getMethods()[0]) });

	final OperationState result = fixture.executeNext(operation);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:26)
	assertNotNull(result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture1_1() throws Exception {
	final Handler fixture = getFixture1();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(31, result);
    }

    /**
     * Run the int hashCode() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHashCode_fixture2_1() throws Exception {
	final Handler fixture = getFixture2();

	final int result = fixture.hashCode();

	// add additional test code here
	assertEquals(31, result);
    }

    /**
     * Run the Handler next(Handler) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testNext_fixture1_1() throws Exception {
	final Handler fixture = getFixture1();
	final Handler handler = null;

	final Handler result = fixture.next(handler);

	// add additional test code here
	assertEquals(null, result);
    }

    /**
     * Run the Handler next(Handler) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testNext_fixture2_1() throws Exception {
	final Handler fixture = getFixture2();
	final Handler handler = null;

	final Handler result = fixture.next(handler);

	// add additional test code here
	assertEquals(null, result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(HandlerTest.class);
    }
}