package edu.issi.machine.subassembly.handler;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.issi.machine.operation.OperationState;

/**
 * The class <code>DefaultHandlerTest</code> contains tests for the class
 * <code>{@link DefaultHandler}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class DefaultHandlerTest {
    /**
     * An instance of the class being tested.
     *
     * @see DefaultHandler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private DefaultHandler fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see DefaultHandler
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public DefaultHandler getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new DefaultHandler();
	}
	return fixture;
    }

    /**
     * Run the OperationState run() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRun_fixture_1() throws Exception {
	final DefaultHandler fixture2 = getFixture();

	final OperationState result = fixture2.run();

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.NullPointerException
	// at
	// edu.issi.machine.subassembly.handler.DefaultHandler.run(DefaultHandler.java:17)
	assertNotNull(result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(DefaultHandlerTest.class);
    }
}