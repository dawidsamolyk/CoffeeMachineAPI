package edu.issi.machine;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>ApplicationTest</code> contains tests for the class
 * <code>{@link Application}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ApplicationTest {
    /**
     * Run the void main(String[]) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = javax.naming.directory.InvalidAttributesException.class)
    public void testMain_1() throws Exception {
	final String[] args = new String[] { "", "0123456789", "An??t-1.0.txt", null };

	Application.main(args);

	// add additional test code here
    }

    /**
     * Run the void main(String[]) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.io.FileNotFoundException.class)
    public void testMain_2() throws Exception {
	final String[] args = new String[] { "" };

	Application.main(args);

	// add additional test code here
    }

    /**
     * Run the void main(String[]) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test(expected = java.io.FileNotFoundException.class)
    public void testMain_3() throws Exception {
	final String[] args = new String[] { "0123456789" };

	Application.main(args);

	// add additional test code here
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ApplicationTest.class);
    }
}