package edu.issi.machine.api;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.junit.*;
import static org.junit.Assert.*;
import edu.issi.machine.id.Identity;
import edu.issi.machine.id.PropertyIdentity;
import edu.issi.machine.operation.ApiMethod;
import edu.issi.machine.operation.Operation;
import edu.issi.machine.product.ingredient.Ingredient;
import edu.issi.machine.product.ingredient.Unit;
import edu.issi.machine.subassembly.Subassembly;

/**
 * The class <code>ApiTest</code> contains tests for the class
 * <code>{@link Api}</code>.
 *
 * @generatedBy CodePro at 01.12.14 19:25
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ApiTest {
    /**
     * An instance of the class being tested.
     *
     * @see Api
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    private Api fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Api
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    public Api getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new Api();
	}
	return fixture;
    }

    /**
     * Run the boolean contains(Method) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testContains_fixture_1() throws Exception {
	Api fixture2 = getFixture();
	Method method = Api.class.getMethods()[0];

	boolean result = fixture2.contains(method);

	// add additional test code here
	assertEquals(true, result);
    }

    /**
     * Run the void execute(Subassembly,Ingredient) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test(expected = IllegalArgumentException.class)
    public void testExecute_fixture_1() throws Exception {
	Api fixture2 = getFixture();
	Subassembly subassembly = new Subassembly(new Identity(0), new Operation[] {
		new Operation(new Identity(0), new ApiMethod[] {
			new ApiMethod(new Api(), Api.class.getMethods()[0]),
			new ApiMethod((Api) null, (Method) null), null }),
		new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(new Api(),
			Api.class.getMethods()[0]) }), null });
	HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	map.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	map.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));
	Ingredient ingredient = new Ingredient(new Identity(0, ""), map);

	fixture2.execute(subassembly, ingredient);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:33)
    }

    /**
     * Run the void execute(Subassembly,Ingredient) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test(expected = IllegalArgumentException.class)
    public void testExecute_fixture_3() throws Exception {
	Api fixture2 = getFixture();

	Subassembly subassembly = new Subassembly(new Identity(0, ""), new Operation[] { new Operation(
		new Identity(0), new ApiMethod[] { new ApiMethod(new Api(), Api.class.getMethods()[0]),
			new ApiMethod((Api) null, (Method) null), null }) });
	HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	map.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	map.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));
	Ingredient ingredient = new Ingredient(new Identity(0, ""), map);

	fixture2.execute(subassembly, ingredient);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:33)
    }

    /**
     * Run the void execute(Subassembly,Ingredient) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test(expected = IllegalArgumentException.class)
    public void testExecute_fixture_4() throws Exception {
	Api fixture2 = getFixture();
	Subassembly subassembly = new Subassembly(new Identity(0), new Operation[] {
		new Operation(new Identity(0), new ApiMethod[] {
			new ApiMethod(new Api(), Api.class.getMethods()[0]),
			new ApiMethod((Api) null, (Method) null), null }),
		new Operation(new Identity(0, ""), new ApiMethod[] { new ApiMethod(new Api(),
			Api.class.getMethods()[0]) }), null });
	HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	Ingredient ingredient = new Ingredient(new Identity(0), map);

	fixture2.execute(subassembly, ingredient);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Wybrane API nie zawiera podanej
	// funkcji!
	// at edu.issi.machine.operation.ApiMethod.<init>(ApiMethod.java:33)
    }

    /**
     * Run the void log(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLog_fixture_1() throws Exception {
	Api fixture2 = getFixture();
	String message = "";

	fixture2.log(message);

	// add additional test code here
    }

    /**
     * Run the void log(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLog_fixture_2() throws Exception {
	Api fixture2 = getFixture();
	String message = "0123456789";

	fixture2.log(message);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLogError_fixture_1() throws Exception {
	Api fixture2 = getFixture();
	Exception e = new Exception("");

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLogError_fixture_2() throws Exception {
	Api fixture2 = getFixture();
	Exception e = new Exception("", new Throwable(""));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLogError_fixture_3() throws Exception {
	Api fixture2 = getFixture();
	Exception e = new Exception("0123456789", new Throwable("", (Throwable) null));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLogError_fixture_4() throws Exception {
	Api fixture2 = getFixture();
	Exception e = new Exception();

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Test
    public void testLogError_fixture_5() throws Exception {
	Api fixture2 = getFixture();
	Exception e = new Exception(new Throwable(""));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 19:25
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ApiTest.class);
    }
}