package edu.issi.machine.api;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.issi.machine.id.Identity;
import edu.issi.machine.id.PropertyIdentity;
import edu.issi.machine.product.ingredient.Ingredient;
import edu.issi.machine.product.ingredient.Unit;

/**
 * The class <code>ApiTest</code> contains tests for the class
 * <code>{@link Api}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class ApiTest {
    /**
     * An instance of the class being tested.
     *
     * @see Api
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Api fixture;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Api
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Api getFixture() throws Exception {
	if (fixture == null) {
	    fixture = new Api();
	}
	return fixture;
    }

    /**
     * Run the boolean contains(Method) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testContains_fixture_1() throws Exception {
	final Api fixture2 = getFixture();
	final Method method = Object.class.getMethods()[0];

	final boolean result = fixture2.contains(method);

	// add additional test code here
	assertEquals(false, result);
    }

    /**
     * Run the void giveCup() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveCup_fixture_1() throws Exception {
	final Api fixture2 = getFixture();

	fixture2.giveCup();

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_1() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.BAR;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_2() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.C;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_3() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.G;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_4() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.KG;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_5() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.L;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_6() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.ML;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_7() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.BAR;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_8() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.C;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_9() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.G;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_10() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.KG;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_11() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.L;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_12() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.ML;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_13() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.BAR;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_14() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.C;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_15() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.G;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_16() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(1);
	final Unit unit = Unit.KG;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_17() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(-1);
	final Unit unit = Unit.L;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void giveIngredient(Integer,Unit) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGiveIngredient_fixture_18() throws Exception {
	final Api fixture2 = getFixture();
	final Integer quantity = new Integer(0);
	final Unit unit = Unit.ML;

	fixture2.giveIngredient(quantity, unit);

	// add additional test code here
    }

    /**
     * Run the void heat(Ingredient) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHeat_fixture_1() throws Exception {
	final Api fixture2 = getFixture();
	final HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	map.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	map.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));
	final Ingredient ingredient = new Ingredient(new Identity(0, ""), map);

	fixture2.heat(ingredient);

	// add additional test code here
    }

    /**
     * Run the void heat(Ingredient) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testHeat_fixture_2() throws Exception {
	final Api fixture2 = getFixture();
	final HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	final Ingredient ingredient = new Ingredient(new Identity(0), map);

	fixture2.heat(ingredient);

	// add additional test code here
    }

    /**
     * Run the void log(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLog_fixture_1() throws Exception {
	final Api fixture2 = getFixture();
	final String message = "";

	fixture2.log(message);

	// add additional test code here
    }

    /**
     * Run the void log(String) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLog_fixture_2() throws Exception {
	final Api fixture2 = getFixture();
	final String message = "0123456789";

	fixture2.log(message);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLogError_fixture_1() throws Exception {
	final Api fixture2 = getFixture();
	final Exception e = new Exception("");

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLogError_fixture_2() throws Exception {
	final Api fixture2 = getFixture();
	final Exception e = new Exception("", new Throwable(""));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLogError_fixture_3() throws Exception {
	final Api fixture2 = getFixture();
	final Exception e = new Exception("0123456789", new Throwable("", (Throwable) null));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLogError_fixture_4() throws Exception {
	final Api fixture2 = getFixture();
	final Exception e = new Exception();

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void logError(Exception) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testLogError_fixture_5() throws Exception {
	final Api fixture2 = getFixture();
	final Exception e = new Exception(new Throwable(""));

	fixture2.logError(e);

	// add additional test code here
    }

    /**
     * Run the void prepareCup() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testPrepareCup_fixture_1() throws Exception {
	final Api fixture2 = getFixture();

	fixture2.prepareCup();

	// add additional test code here
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(ApiTest.class);
    }
}