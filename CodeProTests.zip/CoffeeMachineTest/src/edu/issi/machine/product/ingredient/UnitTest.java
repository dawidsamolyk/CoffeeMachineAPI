package edu.issi.machine.product.ingredient;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The class <code>UnitTest</code> contains tests for the class
 * <code>{@link Unit}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class UnitTest {
    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture2;

    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture3;

    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture4;

    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture5;

    /**
     * An instance of the class being tested.
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Unit fixture6;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture1() throws Exception {
	if (fixture1 == null) {
	    fixture1 = Unit.BAR;
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture2() throws Exception {
	if (fixture2 == null) {
	    fixture2 = Unit.C;
	}
	return fixture2;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture3() throws Exception {
	if (fixture3 == null) {
	    fixture3 = Unit.G;
	}
	return fixture3;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture4() throws Exception {
	if (fixture4 == null) {
	    fixture4 = Unit.KG;
	}
	return fixture4;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture5() throws Exception {
	if (fixture5 == null) {
	    fixture5 = Unit.L;
	}
	return fixture5;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Unit
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Unit getFixture6() throws Exception {
	if (fixture6 == null) {
	    fixture6 = Unit.ML;
	}
	return fixture6;
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture1_1() throws Exception {
	final Unit fixture = getFixture1();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("bar", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture2_1() throws Exception {
	final Unit fixture = getFixture2();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("*C", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture3_1() throws Exception {
	final Unit fixture = getFixture3();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("g", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture4_1() throws Exception {
	final Unit fixture = getFixture4();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("kg", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture5_1() throws Exception {
	final Unit fixture = getFixture5();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("l", result);
    }

    /**
     * Run the String toString() method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testToString_fixture6_1() throws Exception {
	final Unit fixture = getFixture6();

	final String result = fixture.toString();

	// add additional test code here
	assertEquals("ml", result);
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(UnitTest.class);
    }
}