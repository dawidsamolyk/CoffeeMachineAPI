package edu.issi.machine.product.ingredient;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.issi.machine.id.Identity;
import edu.issi.machine.id.PropertyIdentity;

/**
 * The class <code>IngredientTest</code> contains tests for the class
 * <code>{@link Ingredient}</code>.
 *
 * @generatedBy CodePro at 01.12.14 17:05
 * @author Dawid
 * @version $Revision: 1.0 $
 */
public class IngredientTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();
    
    /**
     * An instance of the class being tested.
     *
     * @see Ingredient
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Ingredient fixture1;

    /**
     * An instance of the class being tested.
     *
     * @see Ingredient
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    private Ingredient fixture2;

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Ingredient
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Ingredient getFixture1() throws Exception {
	if (fixture1 == null) {
	    final HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	    map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	    map.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	    map.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));
	    fixture1 = new Ingredient(new Identity(0, ""), map);
	}
	return fixture1;
    }

    /**
     * Return an instance of the class being tested.
     *
     * @return an instance of the class being tested
     *
     * @see Ingredient
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public Ingredient getFixture2() throws Exception {
	if (fixture2 == null) {
	    final HashMap<PropertyIdentity, Double> map = new HashMap<PropertyIdentity, Double>();
	    map.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	    fixture2 = new Ingredient(new Identity(0), map);
	}
	return fixture2;
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_1() throws Exception {
	final Identity identity = new Identity(0);
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_2() throws Exception {
	final Identity identity = new Identity(0, "");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_3() throws Exception {
	final Identity identity = new Identity(1, "0123456789");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_4() throws Exception {
	final Identity identity = new Identity(0);
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_5() throws Exception {
	final Identity identity = new Identity(0, "");
	final Map<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();

	exception.expect(IllegalArgumentException.class);
	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Lista w�a�ciwo�ci sk�adnika nie
	// mo�e by� pusta lub niepe�na!
	// at
	// edu.issi.machine.Validator.throwExceptionWhenMapContainsNullOrEmpty(Validator.java:110)
	// at
	// edu.issi.machine.product.ingredient.Ingredient.<init>(Ingredient.java:33)
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_6() throws Exception {
	final Identity identity = new Identity(0);
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_7() throws Exception {
	final Identity identity = new Identity(0, "");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_8() throws Exception {
	final Identity identity = new Identity(1, "0123456789");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_9() throws Exception {
	final Identity identity = new Identity(0);
	final Map<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();

	exception.expect(IllegalArgumentException.class);
	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Lista w�a�ciwo�ci sk�adnika nie
	// mo�e by� pusta lub niepe�na!
	// at
	// edu.issi.machine.Validator.throwExceptionWhenMapContainsNullOrEmpty(Validator.java:110)
	// at
	// edu.issi.machine.product.ingredient.Ingredient.<init>(Ingredient.java:33)
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_10() throws Exception {
	final Identity identity = new Identity(1, "0123456789");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_11() throws Exception {
	final Identity identity = new Identity(0);
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_12() throws Exception {
	final Identity identity = new Identity(0, "");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_13() throws Exception {
	final Identity identity = new Identity(1, "0123456789");
	final Map<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();

	exception.expect(IllegalArgumentException.class);
	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.lang.IllegalArgumentException: Lista w�a�ciwo�ci sk�adnika nie
	// mo�e by� pusta lub niepe�na!
	// at
	// edu.issi.machine.Validator.throwExceptionWhenMapContainsNullOrEmpty(Validator.java:110)
	// at
	// edu.issi.machine.product.ingredient.Ingredient.<init>(Ingredient.java:33)
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_14() throws Exception {
	final Identity identity = new Identity(0, "");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the Ingredient(Identity,Map<PropertyIdentity,Double>) constructor
     * test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testIngredient_15() throws Exception {
	final Identity identity = new Identity(1, "0123456789");
	final HashMap<PropertyIdentity, Double> properties = new HashMap<PropertyIdentity, Double>();
	properties.put(new PropertyIdentity(0, "", Unit.BAR), new Double(-1.0));
	properties.put(new PropertyIdentity(1, "0123456789", Unit.C), new Double(0.0));
	properties.put(new PropertyIdentity(7, "An??t-1.0.txt", Unit.G), new Double(1.0));

	final Ingredient result = new Ingredient(identity, properties);

	// add additional test code here
	assertNotNull(result);
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_1() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_1() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_2() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_3() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_2() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_3() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_4() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_5() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_4() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_5() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_6() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_6() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_7() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_7() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_8() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_8() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);
	final Double value = new Double(-1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture2_9() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);
	final Double value = new Double(0.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the void add(PropertyIdentity,Double) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testAdd_fixture1_9() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);
	final Double value = new Double(1.0);

	fixture.add(property, value);

	// add additional test code here
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture1_1() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);

	final Double result = fixture.get(property);

	// add additional test code here
	assertNotNull(result);
	assertEquals("-1.0", result.toString());
	assertEquals((byte) -1, result.byteValue());
	assertEquals((short) -1, result.shortValue());
	assertEquals(-1, result.intValue());
	assertEquals(-1L, result.longValue());
	assertEquals(-1.0f, result.floatValue(), 1.0f);
	assertEquals(-1.0, result.doubleValue(), 1.0);
	assertEquals(false, result.isNaN());
	assertEquals(false, result.isInfinite());
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture2_1() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);

	exception.expect(NoSuchElementException.class);
	final Double result = fixture.get(property);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.util.NoSuchElementException: Wybrany sk�adnik nie posiada
	// podanej w�a�ciwo�ci!
	// at
	// edu.issi.machine.product.ingredient.Ingredient.get(Ingredient.java:48)
	assertNotNull(result);
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture1_2() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);

	final Double result = fixture.get(property);

	// add additional test code here
	assertNotNull(result);
	assertEquals("1.0", result.toString());
	assertEquals((byte) 1, result.byteValue());
	assertEquals((short) 1, result.shortValue());
	assertEquals(1, result.intValue());
	assertEquals(1L, result.longValue());
	assertEquals(1.0f, result.floatValue(), 1.0f);
	assertEquals(1.0, result.doubleValue(), 1.0);
	assertEquals(false, result.isNaN());
	assertEquals(false, result.isInfinite());
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture1_3() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);

	final Double result = fixture.get(property);

	// add additional test code here
	assertNotNull(result);
	assertEquals("0.0", result.toString());
	assertEquals((byte) 0, result.byteValue());
	assertEquals((short) 0, result.shortValue());
	assertEquals(0, result.intValue());
	assertEquals(0L, result.longValue());
	assertEquals(0.0f, result.floatValue(), 1.0f);
	assertEquals(0.0, result.doubleValue(), 1.0);
	assertEquals(false, result.isNaN());
	assertEquals(false, result.isInfinite());
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture2_2() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);

	exception.expect(NoSuchElementException.class);
	final Double result = fixture.get(property);

	// add additional test code here
	// An unexpected exception was thrown in user code while executing this
	// test:
	// java.util.NoSuchElementException: Wybrany sk�adnik nie posiada
	// podanej w�a�ciwo�ci!
	// at
	// edu.issi.machine.product.ingredient.Ingredient.get(Ingredient.java:48)
	assertNotNull(result);
    }

    /**
     * Run the Double get(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testGet_fixture2_3() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);

	final Double result = fixture.get(property);

	// add additional test code here
	assertNotNull(result);
	assertEquals("-1.0", result.toString());
	assertEquals((byte) -1, result.byteValue());
	assertEquals((short) -1, result.shortValue());
	assertEquals(-1, result.intValue());
	assertEquals(-1L, result.longValue());
	assertEquals(-1.0f, result.floatValue(), 1.0f);
	assertEquals(-1.0, result.doubleValue(), 1.0);
	assertEquals(false, result.isNaN());
	assertEquals(false, result.isInfinite());
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture1_1() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture2_1() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture1_2() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture1_3() throws Exception {
	final Ingredient fixture = getFixture1();
	final PropertyIdentity property = new PropertyIdentity(1, "0123456789", Unit.C);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture2_2() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(7, "An??t-1.0.txt", Unit.G);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Run the void remove(PropertyIdentity) method test.
     *
     * @throws Exception
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Test
    public void testRemove_fixture2_3() throws Exception {
	final Ingredient fixture = getFixture2();
	final PropertyIdentity property = new PropertyIdentity(0, "", Unit.BAR);

	fixture.remove(property);

	// add additional test code here
    }

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @Before
    public void setUp() throws Exception {
	// add additional set up code here
    }

    /**
     * Perform post-test clean-up.
     *
     * @throws Exception
     *             if the clean-up fails for some reason
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    @After
    public void tearDown() throws Exception {
	// Add additional tear down code here
    }

    /**
     * Launch the test.
     *
     * @param args
     *            the command line arguments
     *
     * @generatedBy CodePro at 01.12.14 17:05
     */
    public static void main(String[] args) {
	new org.junit.runner.JUnitCore().run(IngredientTest.class);
    }
}